#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

bool isConsonant(char letter) {
  if(letter == 'a' || letter == 'e' || letter == 'i' || letter == 'o' || letter == 'u' || letter == 'A' || letter == 'E' || letter == 'I' || letter == 'O' || letter == 'u'){
    return false;
  } else {
    return true;
  }
}

string toPigLatin(string word) {
string constCluter;

for(int i = 0; i < word.length(); i++) {
if (isConsonant(word[i])) {
constCluter += word[i];
word.erase(i, 1);
i -= 1;
} else {
break;
}
}

return word + constCluter + "-ay";
}

int main() {
  string word;
  cout << "Please input a word that you want converted to pig latin" << endl;
  cin >> word;
  word = toPigLatin(word);
  cout << word << std::endl;
  return 0;
}
